# Credit Risk Assessment System

Predicts a borrower's **probability of default (PD)** and turns it into an approve/reject decision, with
**probability calibration**, **cost-based threshold optimisation** and **SHAP explainability**.

## Quick start
```bash
pip install -r requirements.txt
python train.py                      # trains, calibrates, optimises threshold, evaluates, explains
python -m src.predict                # score the built-in sample applicant with reason codes
python -m pytest -q                  # 14 tests
```
Use your own data: `python train.py --csv loans.csv` (columns listed in `src/config.py`; target `default` = 0/1).
Options: `--cost-fn 5 --cost-fp 1 --calibration auto|isotonic|sigmoid --samples 20000 --seed 42`.

## Pipeline
| Step | What happens | Where |
|---|---|---|
| Split | Stratified train / calibration / validation / test (see below) | `pipeline.split_data` |
| Models | Logistic Regression, Random Forest, Gradient Boosting; best validation AUC wins | `pipeline.py` |
| Calibration | Isotonic or Platt (sigmoid) fitted on a **separate calibration split** | `calibration.py` |
| Threshold | Sweep 0.01-0.99 on validation; pick min cost = `cost_fn*FN + cost_fp*FP` | `thresholds.py` |
| Evaluation | AUC, Gini, KS, PR-AUC, Brier, log-loss, ECE, confusion matrix, cost per loan on untouched test set | `metrics.py` |
| SHAP | Global summary/bar plots, waterfall plots, per-applicant reason codes | `explain.py` |

Splits (of all data): test 20%; remaining 80% -> train 60%, calibration 20%, validation 20% of that remainder.
No split is reused for a different purpose, so there is no leakage.

## Why these three techniques
* **Calibration**: a score of 0.2 should mean ~20% of such borrowers default. Needed for pricing, expected loss and regulation.
* **Threshold optimisation**: approving a defaulter costs far more than rejecting a good customer, so 0.5 is the wrong cut.
  With calibrated PDs the theoretical optimum is `cost_fp / (cost_fp + cost_fn)` (= 0.167 for 5:1); the sweep finds it empirically.
* **SHAP**: shows which features drive each decision; reason codes list the top factors raising an applicant's risk.
  SHAP explains the model's raw score (log-odds for LR/GB); calibration is a monotone map applied afterwards, so the ranking of reasons is unchanged.

## Outputs (`outputs/`)
`metrics.json`, `credit_risk_model.joblib`, `calibration_curve.png`, `threshold_curve.png`, `roc_curve.png`,
`shap_summary.png`, `shap_importance_bar.png`, `shap_waterfall_{high,low}_risk.png`, `shap_global_importance.csv`, `threshold_sweep.csv`.

## Notes
* Default data is **synthetic** (realistic drivers, injected missing values). Swap in a real dataset (e.g. German Credit,
  Give Me Some Credit) by mapping its columns to `src/config.py`.
* Tune `cost_fn`/`cost_fp` to your real loss given default vs. lost margin.
