"""Data loading. Generates a realistic synthetic credit dataset, or loads your own CSV."""
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from .config import CATEGORICAL_FEATURES, NUMERIC_FEATURES, TARGET


def generate_synthetic_data(n_samples: int = 20000, seed: int = 42) -> pd.DataFrame:
    """Create a synthetic loan portfolio where default risk depends on sensible drivers."""
    rng = np.random.default_rng(seed)
    n = n_samples

    age = np.clip(rng.normal(40, 11, n), 18, 75).round()
    education = rng.choice(["high_school", "bachelor", "master", "phd"], n, p=[0.35, 0.40, 0.20, 0.05])
    edu_bonus = pd.Series(education).map({"high_school": 0, "bachelor": 0.15, "master": 0.25, "phd": 0.30}).to_numpy()
    annual_income = np.exp(rng.normal(10.9 + edu_bonus, 0.45, n)).round(-2)
    employment_years = np.clip((age - 20) * rng.uniform(0.1, 0.9, n), 0, 45).round(1)
    credit_history_years = np.clip((age - 18) * rng.uniform(0.1, 0.8, n), 0, 50).round(1)
    num_credit_lines = np.clip(rng.poisson(5, n), 0, 25)
    num_late_payments = np.clip(rng.poisson(0.8 + (credit_history_years < 3) * 0.8, n), 0, 15)
    credit_utilization = np.clip(rng.beta(2, 4, n), 0, 1).round(3)
    home_ownership = rng.choice(["rent", "mortgage", "own"], n, p=[0.45, 0.40, 0.15])
    loan_purpose = rng.choice(
        ["debt_consolidation", "home_improvement", "car", "education", "medical", "business", "other"],
        n, p=[0.30, 0.15, 0.15, 0.10, 0.08, 0.10, 0.12],
    )
    loan_amount = np.clip(annual_income * rng.uniform(0.05, 0.6, n), 1000, 100000).round(-2)
    loan_term_months = rng.choice([12, 24, 36, 48, 60], n, p=[0.10, 0.15, 0.40, 0.15, 0.20])
    monthly_debt = annual_income / 12 * rng.uniform(0.05, 0.45, n) + loan_amount / loan_term_months
    debt_to_income = np.clip(monthly_debt * 12 / annual_income, 0, 1.5).round(3)

    # Interest rate reflects (noisy) lender pricing of risk.
    interest_rate = np.clip(
        6 + 12 * credit_utilization + 0.6 * num_late_payments - 0.05 * credit_history_years
        + rng.normal(0, 1.5, n), 3, 30,
    ).round(2)

    purpose_risk = pd.Series(loan_purpose).map({
        "debt_consolidation": 0.1, "home_improvement": -0.2, "car": -0.1, "education": 0.0,
        "medical": 0.3, "business": 0.5, "other": 0.2,
    }).to_numpy()
    home_risk = pd.Series(home_ownership).map({"rent": 0.3, "mortgage": 0.0, "own": -0.3}).to_numpy()

    logit = (
        -3.0
        + 2.2 * credit_utilization
        + 0.35 * num_late_payments
        + 2.0 * np.clip(debt_to_income - 0.3, 0, None)
        + 0.8 * (loan_amount / annual_income)
        + 0.04 * (interest_rate - 12)
        - 0.05 * np.minimum(employment_years, 15)
        - 0.03 * np.minimum(credit_history_years, 20)
        - 0.15 * (np.log(annual_income) - 10.9)
        + 0.004 * (loan_term_months - 36)
        + purpose_risk + home_risk
        + rng.normal(0, 0.5, n)
    )
    default = (rng.random(n) < 1 / (1 + np.exp(-logit))).astype(int)

    df = pd.DataFrame({
        "age": age, "annual_income": annual_income, "loan_amount": loan_amount,
        "loan_term_months": loan_term_months, "interest_rate": interest_rate,
        "employment_years": employment_years, "credit_history_years": credit_history_years,
        "num_credit_lines": num_credit_lines, "num_late_payments": num_late_payments,
        "credit_utilization": credit_utilization, "debt_to_income": debt_to_income,
        "home_ownership": home_ownership, "loan_purpose": loan_purpose, "education": education,
        TARGET: default,
    })

    # Inject realistic missing values so the imputation path is exercised.
    for col, frac in [("employment_years", 0.04), ("credit_utilization", 0.03), ("annual_income", 0.02)]:
        df.loc[rng.random(n) < frac, col] = np.nan
    return df


def load_data(csv_path: Optional[str] = None, n_samples: int = 20000, seed: int = 42) -> pd.DataFrame:
    """Load a CSV (must contain the configured feature columns and the target) or synthesize data."""
    if csv_path is None:
        return generate_synthetic_data(n_samples, seed)
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")
    df = pd.read_csv(path)
    validate_dataframe(df)
    return df


def validate_dataframe(df: pd.DataFrame) -> None:
    required = NUMERIC_FEATURES + CATEGORICAL_FEATURES + [TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    if df[TARGET].isna().any():
        raise ValueError(f"Target column '{TARGET}' contains missing values.")
    if not set(df[TARGET].unique()) <= {0, 1}:
        raise ValueError(f"Target column '{TARGET}' must be binary (0/1).")
    if df[TARGET].nunique() < 2:
        raise ValueError("Target has only one class; cannot train a classifier.")
