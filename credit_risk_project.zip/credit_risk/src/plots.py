"""Diagnostic plots: calibration, threshold/cost curve and ROC."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
from sklearn.metrics import roc_curve


def plot_calibration(y, p_raw, p_cal, path, n_bins: int = 10):
    plt.figure(figsize=(6, 6))
    plt.plot([0, 1], [0, 1], "k--", label="Perfectly calibrated")
    for label, p in [("Before calibration", p_raw), ("After calibration", p_cal)]:
        frac_pos, mean_pred = calibration_curve(y, p, n_bins=n_bins, strategy="quantile")
        plt.plot(mean_pred, frac_pos, marker="o", label=label)
    plt.xlabel("Mean predicted probability of default")
    plt.ylabel("Observed default rate")
    plt.title("Reliability diagram (test set)")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close("all")


def plot_threshold_curve(curve, best_threshold, path):
    fig, ax1 = plt.subplots(figsize=(8, 5))
    ax1.plot(curve["threshold"], curve["cost_per_loan"], color="tab:red", label="Cost per loan")
    ax1.set_xlabel("Decision threshold (reject if PD >= threshold)")
    ax1.set_ylabel("Cost per loan", color="tab:red")
    ax1.axvline(best_threshold, color="k", linestyle="--", label=f"Optimal = {best_threshold:.2f}")
    ax2 = ax1.twinx()
    ax2.plot(curve["threshold"], curve["recall"], color="tab:blue", label="Recall (defaults caught)")
    ax2.plot(curve["threshold"], curve["precision"], color="tab:green", label="Precision")
    ax2.set_ylabel("Recall / Precision")
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper center")
    ax1.set_title("Threshold optimisation (validation set)")
    ax1.grid(alpha=0.3)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close("all")


def plot_roc(y, p, auc, path):
    fpr, tpr, _ = roc_curve(y, p)
    plt.figure(figsize=(6, 6))
    plt.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
    plt.plot([0, 1], [0, 1], "k--")
    plt.xlabel("False positive rate")
    plt.ylabel("True positive rate")
    plt.title("ROC curve (test set)")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close("all")
