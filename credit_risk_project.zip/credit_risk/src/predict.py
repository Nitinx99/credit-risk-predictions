"""Score new applicants with the saved model:  python -m src.predict [--csv applicants.csv]"""
import argparse

import joblib
import pandas as pd

from . import explain
from .config import CATEGORICAL_FEATURES, NUMERIC_FEATURES, OUTPUT_DIR

FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

SAMPLE_APPLICANT = {
    "age": 29, "annual_income": 42000, "loan_amount": 25000, "loan_term_months": 60,
    "interest_rate": 17.5, "employment_years": 2, "credit_history_years": 3,
    "num_credit_lines": 4, "num_late_payments": 4, "credit_utilization": 0.85,
    "debt_to_income": 0.55, "home_ownership": "rent", "loan_purpose": "business",
    "education": "high_school",
}


def load_bundle(path=OUTPUT_DIR / "credit_risk_model.joblib"):
    return joblib.load(path)


def score_applicants(bundle: dict, applicants: pd.DataFrame, top_k: int = 3) -> pd.DataFrame:
    missing = [c for c in FEATURES if c not in applicants.columns]
    if missing:
        raise ValueError(f"Applicant data is missing columns: {missing}")
    pre, model = bundle["preprocessor"], bundle["model"]
    names = list(pre.get_feature_names_out())
    X = pd.DataFrame(pre.transform(applicants[FEATURES]), columns=names, index=applicants.index)
    pd_cal = bundle["calibrator"].predict(model.predict_proba(X)[:, 1])
    explainer = explain.build_explainer(model, bundle["background"])
    sv, _ = explain.shap_values(explainer, X)
    out = pd.DataFrame({
        "probability_of_default": pd_cal,
        "decision": ["REJECT" if p >= bundle["threshold"] else "APPROVE" for p in pd_cal],
    }, index=applicants.index)
    reasons = []
    for i in range(len(X)):
        shown = explain.display_values(names, applicants.iloc[i], X.iloc[i].to_numpy())
        reasons.append("; ".join(explain.reason_codes(sv[i], names, shown, top_k)) or "none")
    out["top_risk_reasons"] = reasons
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=None, help="CSV of applicants (feature columns only)")
    ap.add_argument("--model", default=str(OUTPUT_DIR / "credit_risk_model.joblib"))
    a = ap.parse_args()
    bundle = load_bundle(a.model)
    df = pd.read_csv(a.csv) if a.csv else pd.DataFrame([SAMPLE_APPLICANT])
    res = score_applicants(bundle, df)
    pd.set_option("display.max_colwidth", 200, "display.width", 250)
    print(f"Decision threshold: {bundle['threshold']:.2f}")
    print(res.to_string())


if __name__ == "__main__":
    main()
