"""SHAP explainability: global importance, local explanations and adverse-action reason codes."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from sklearn.linear_model import LogisticRegression


def build_explainer(model, background: pd.DataFrame):
    """TreeExplainer for tree ensembles, LinearExplainer for logistic regression."""
    if isinstance(model, LogisticRegression):
        return shap.LinearExplainer(model, background)
    return shap.TreeExplainer(model)


def _positive_class(values):
    """Normalise SHAP output across model types/versions to a 2-D (rows, features) array."""
    if isinstance(values, list):
        values = values[-1]
    values = np.asarray(values)
    if values.ndim == 3:
        values = values[:, :, -1]
    return values


def shap_values(explainer, X: pd.DataFrame):
    """Return (values, base_value) for the default class, in the model's raw output space
    (log-odds for logistic regression / gradient boosting, probability for random forest)."""
    try:
        raw = explainer.shap_values(X, check_additivity=False)
    except TypeError:
        raw = explainer.shap_values(X)
    values = _positive_class(raw)
    base = np.ravel(explainer.expected_value)[-1]
    return values, float(base)


def display_values(feature_names, raw_row: pd.Series, transformed_row):
    """Human-readable values: original (unscaled) value for numeric/raw columns, else the encoded value."""
    out = []
    for i, name in enumerate(feature_names):
        if name in raw_row.index:
            v = raw_row[name]
            out.append("missing" if pd.isna(v) else v)
        else:
            out.append(transformed_row[i])
    return out


def _fmt(v):
    return v if isinstance(v, str) else f"{float(v):.3g}"


def reason_codes(values_row, feature_names, feature_row, top_k: int = 3):
    """Top features pushing this applicant's risk UP (what a lender cites as adverse-action reasons)."""
    order = np.argsort(values_row)[::-1]
    reasons = []
    for i in order:
        if values_row[i] <= 0 or len(reasons) >= top_k:
            break
        reasons.append(f"{feature_names[i]} = {_fmt(feature_row[i])} (+{values_row[i]:.3f})")
    return reasons


def save_global_plots(values, X: pd.DataFrame, out_dir):
    plt.figure()
    shap.summary_plot(values, X, show=False, max_display=15)
    plt.tight_layout()
    plt.savefig(out_dir / "shap_summary.png", dpi=150, bbox_inches="tight")
    plt.close("all")

    plt.figure()
    shap.summary_plot(values, X, plot_type="bar", show=False, max_display=15)
    plt.tight_layout()
    plt.savefig(out_dir / "shap_importance_bar.png", dpi=150, bbox_inches="tight")
    plt.close("all")


def save_waterfall(values_row, base_value, X_row: pd.Series, path, max_display: int = 10):
    exp = shap.Explanation(values=values_row, base_values=base_value,
                           data=X_row.to_numpy(), feature_names=list(X_row.index))
    plt.figure()
    shap.plots.waterfall(exp, max_display=max_display, show=False)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close("all")


def global_importance(values, feature_names) -> pd.DataFrame:
    imp = np.abs(values).mean(axis=0)
    return (pd.DataFrame({"feature": list(feature_names), "mean_abs_shap": imp})
            .sort_values("mean_abs_shap", ascending=False).reset_index(drop=True))
