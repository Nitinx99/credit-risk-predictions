"""Evaluation metrics: discrimination, calibration and business cost."""
import numpy as np
from sklearn.metrics import (average_precision_score, brier_score_loss, log_loss,
                             roc_auc_score, roc_curve)

from .thresholds import confusion_counts


def expected_calibration_error(y, p, n_bins: int = 10) -> float:
    y = np.asarray(y).astype(float)
    p = np.asarray(p, dtype=float)
    edges = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, n_bins - 1)
    ece = 0.0
    for b in range(n_bins):
        mask = idx == b
        if mask.any():
            ece += mask.mean() * abs(y[mask].mean() - p[mask].mean())
    return float(ece)


def ks_statistic(y, p) -> float:
    fpr, tpr, _ = roc_curve(y, p)
    return float(np.max(tpr - fpr))


def evaluate(y, p, threshold, cost_fn=5.0, cost_fp=1.0) -> dict:
    y = np.asarray(y).astype(int)
    p = np.clip(np.asarray(p, dtype=float), 1e-6, 1 - 1e-6)
    tp, fp, fn, tn = confusion_counts(y, p, threshold)
    n = len(y)
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    cost = cost_fn * fn + cost_fp * fp
    naive_cost = min(cost_fn * int(y.sum()), cost_fp * int(n - y.sum()))  # approve-all vs reject-all
    return {
        "roc_auc": float(roc_auc_score(y, p)),
        "gini": float(2 * roc_auc_score(y, p) - 1),
        "ks": ks_statistic(y, p),
        "pr_auc": float(average_precision_score(y, p)),
        "brier": float(brier_score_loss(y, p)),
        "log_loss": float(log_loss(y, p)),
        "ece": expected_calibration_error(y, p),
        "threshold": float(threshold),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "recall": float(recall), "precision": float(precision),
        "accuracy": float((tp + tn) / n),
        "total_cost": float(cost),
        "cost_per_loan": float(cost / n),
        "baseline_cost_per_loan": float(naive_cost / n),
        "mean_predicted_pd": float(p.mean()),
        "observed_default_rate": float(y.mean()),
    }
