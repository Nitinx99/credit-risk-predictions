"""Probability calibration fitted on a dedicated hold-out set (never on training data)."""
import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

EPS = 1e-3  # keep probabilities strictly inside (0, 1): no overconfident 0%/100% outputs


class ProbabilityCalibrator:
    """Maps raw model scores to calibrated default probabilities.

    method="isotonic": non-parametric, monotone step function (needs a few thousand rows).
    method="sigmoid" : Platt scaling, logistic regression on the logit of the raw score.
    """

    def __init__(self, method: str = "isotonic"):
        if method not in ("isotonic", "sigmoid"):
            raise ValueError("method must be 'isotonic' or 'sigmoid'")
        self.method = method
        self._model = None

    @staticmethod
    def _logit(p):
        p = np.clip(np.asarray(p, dtype=float), EPS, 1 - EPS)
        return np.log(p / (1 - p)).reshape(-1, 1)

    def fit(self, raw_prob, y):
        raw_prob = np.asarray(raw_prob, dtype=float).ravel()
        y = np.asarray(y).astype(int).ravel()
        if len(raw_prob) != len(y):
            raise ValueError("raw_prob and y must have the same length")
        if len(np.unique(y)) < 2:
            raise ValueError("Calibration set must contain both classes")
        if self.method == "isotonic":
            self._model = IsotonicRegression(y_min=0.0, y_max=1.0, out_of_bounds="clip")
            self._model.fit(raw_prob, y)
        else:
            self._model = LogisticRegression(C=1e6, max_iter=1000)
            self._model.fit(self._logit(raw_prob), y)
        return self

    def predict(self, raw_prob):
        if self._model is None:
            raise RuntimeError("Calibrator is not fitted yet")
        raw_prob = np.asarray(raw_prob, dtype=float).ravel()
        if self.method == "isotonic":
            out = self._model.predict(raw_prob)
        else:
            out = self._model.predict_proba(self._logit(raw_prob))[:, 1]
        return np.clip(out, EPS, 1 - EPS)
