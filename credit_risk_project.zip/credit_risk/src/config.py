"""Central configuration for the credit risk project."""
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "outputs"

TARGET = "default"  # 1 = borrower defaulted (bad), 0 = repaid (good)

NUMERIC_FEATURES = [
    "age", "annual_income", "loan_amount", "loan_term_months", "interest_rate",
    "employment_years", "credit_history_years", "num_credit_lines",
    "num_late_payments", "credit_utilization", "debt_to_income",
]
CATEGORICAL_FEATURES = ["home_ownership", "loan_purpose", "education"]


@dataclass
class Settings:
    seed: int = 42
    n_samples: int = 20000
    test_size: float = 0.20       # final hold-out, never touched until the end
    calib_size: float = 0.20      # of the remaining data: fits the calibrator
    val_size: float = 0.20        # of the remaining data: model selection + threshold
    # Business costs: a missed defaulter (false negative) loses principal,
    # a wrongly rejected good customer (false positive) loses only interest.
    cost_fn: float = 5.0
    cost_fp: float = 1.0
    calibration_method: str = "auto"   # "auto", "isotonic" or "sigmoid"
    shap_sample_size: int = 500
