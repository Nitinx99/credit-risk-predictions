"""End-to-end training pipeline:
split -> model selection -> calibration -> threshold optimisation -> test evaluation -> SHAP."""
import json
from typing import Optional

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, roc_auc_score
from sklearn.model_selection import train_test_split

from . import explain, plots
from .calibration import ProbabilityCalibrator
from .config import OUTPUT_DIR, TARGET, Settings
from .data import load_data, validate_dataframe
from .metrics import evaluate
from .preprocessing import build_preprocessor
from .thresholds import optimize_threshold


def split_data(df: pd.DataFrame, s: Settings):
    """Stratified train / calibration / validation / test split."""
    hold = s.calib_size + s.val_size
    if not (0 < s.test_size < 1 and 0 < hold < 1):
        raise ValueError("Split fractions must leave room for a training set")
    X, y = df.drop(columns=[TARGET]), df[TARGET].astype(int)
    X_rest, X_test, y_rest, y_test = train_test_split(
        X, y, test_size=s.test_size, stratify=y, random_state=s.seed)
    X_train, X_tmp, y_train, y_tmp = train_test_split(
        X_rest, y_rest, test_size=hold, stratify=y_rest, random_state=s.seed)
    X_cal, X_val, y_cal, y_val = train_test_split(
        X_tmp, y_tmp, test_size=s.val_size / hold, stratify=y_tmp, random_state=s.seed)
    return (X_train, y_train), (X_cal, y_cal), (X_val, y_val), (X_test, y_test)


def candidate_models(seed: int):
    """name -> (scale_numeric, estimator)."""
    return {
        "logistic_regression": (True, LogisticRegression(max_iter=2000, random_state=seed)),
        "random_forest": (False, RandomForestClassifier(
            n_estimators=300, min_samples_leaf=20, n_jobs=-1, random_state=seed)),
        "gradient_boosting": (False, GradientBoostingClassifier(
            n_estimators=200, learning_rate=0.05, max_depth=3, subsample=0.8, random_state=seed)),
    }


def _frame(preprocessor, X: pd.DataFrame) -> pd.DataFrame:
    names = list(preprocessor.get_feature_names_out())
    return pd.DataFrame(preprocessor.transform(X), columns=names, index=X.index)


def run_pipeline(settings: Optional[Settings] = None, csv_path: Optional[str] = None,
                 output_dir=OUTPUT_DIR, verbose: bool = True) -> dict:
    s = settings or Settings()
    out = output_dir
    out.mkdir(parents=True, exist_ok=True)
    log = print if verbose else (lambda *a, **k: None)

    df = load_data(csv_path, s.n_samples, s.seed)
    validate_dataframe(df)
    log(f"Loaded {len(df):,} loans | default rate = {df[TARGET].mean():.1%}")

    (X_tr, y_tr), (X_cal, y_cal), (X_val, y_val), (X_te, y_te) = split_data(df, s)
    log(f"Split sizes -> train {len(X_tr):,} | calibration {len(X_cal):,} | "
        f"validation {len(X_val):,} | test {len(X_te):,}")

    # 1) Model selection on validation AUC (raw, uncalibrated scores; AUC is calibration-invariant)
    fitted, val_auc, cal_compare = {}, {}, {}
    for name, (scale, est) in candidate_models(s.seed).items():
        pre = build_preprocessor(scale).fit(X_tr)
        est.fit(_frame(pre, X_tr), y_tr)
        p_val = est.predict_proba(_frame(pre, X_val))[:, 1]
        p_cal_raw = est.predict_proba(_frame(pre, X_cal))[:, 1]
        fitted[name] = (pre, est)
        val_auc[name] = float(roc_auc_score(y_val, p_val))
        # Validation Brier score: raw vs each calibration method (calibrator fitted on the calibration split)
        scores = {"raw": float(brier_score_loss(y_val, p_val))}
        for method in ("isotonic", "sigmoid"):
            cal = ProbabilityCalibrator(method).fit(p_cal_raw, y_cal)
            scores[method] = float(brier_score_loss(y_val, cal.predict(p_val)))
        cal_compare[name] = scores
        log(f"  {name:<20s} val AUC = {val_auc[name]:.4f} | val Brier raw {scores['raw']:.4f} "
            f"/ isotonic {scores['isotonic']:.4f} / sigmoid {scores['sigmoid']:.4f}")
    best_name = max(val_auc, key=val_auc.get)
    pre, model = fitted[best_name]
    log(f"Selected model: {best_name}")

    def raw_score(X):
        return model.predict_proba(_frame(pre, X))[:, 1]

    # 2) Probability calibration, fitted ONLY on the calibration split
    method = s.calibration_method
    if method == "auto":
        c = cal_compare[best_name]
        method = "isotonic" if c["isotonic"] < 0.99 * c["sigmoid"] else "sigmoid"
    calibrator = ProbabilityCalibrator(method).fit(raw_score(X_cal), y_cal)
    log(f"Calibration method: {method}")

    # 3) Threshold optimisation on the validation split using calibrated probabilities
    p_val_cal = calibrator.predict(raw_score(X_val))
    thr = optimize_threshold(y_val, p_val_cal, s.cost_fn, s.cost_fp)
    threshold = thr["best_threshold"]
    log(f"Optimal threshold = {threshold:.2f} (cost FN={s.cost_fn}, FP={s.cost_fp}; "
        f"theoretical = {thr['theoretical_threshold']:.3f})")

    # 4) Final, untouched test-set evaluation
    p_te_raw = raw_score(X_te)
    p_te_cal = calibrator.predict(p_te_raw)
    results = {
        "selected_model": best_name,
        "validation_auc": val_auc,
        "validation_brier_by_calibration": cal_compare,
        "calibration_method": method,
        "thresholds": {k: v for k, v in thr.items() if k != "curve"},
        "test_uncalibrated": evaluate(y_te, p_te_raw, threshold, s.cost_fn, s.cost_fp),
        "test_calibrated": evaluate(y_te, p_te_cal, threshold, s.cost_fn, s.cost_fp),
        "test_calibrated_at_default_0.5": evaluate(y_te, p_te_cal, 0.5, s.cost_fn, s.cost_fp),
    }
    plots.plot_calibration(y_te, p_te_raw, p_te_cal, out / "calibration_curve.png")
    plots.plot_threshold_curve(thr["curve"], threshold, out / "threshold_curve.png")
    plots.plot_roc(y_te, p_te_cal, results["test_calibrated"]["roc_auc"], out / "roc_curve.png")
    thr["curve"].to_csv(out / "threshold_sweep.csv", index=False)

    # 5) SHAP explainability
    n_bg = min(100, len(X_tr))
    background = _frame(pre, X_tr.sample(n_bg, random_state=s.seed))
    explainer = explain.build_explainer(model, background)
    n_shap = min(s.shap_sample_size, len(X_te))
    X_shap = _frame(pre, X_te.sample(n_shap, random_state=s.seed))
    sv, base = explain.shap_values(explainer, X_shap)
    explain.save_global_plots(sv, X_shap, out)
    importance = explain.global_importance(sv, X_shap.columns)
    importance.to_csv(out / "shap_global_importance.csv", index=False)
    results["top_shap_features"] = importance.head(10).to_dict("records")

    # Local explanations: highest- and lowest-risk applicants in the SHAP sample
    risk = calibrator.predict(model.predict_proba(X_shap)[:, 1])
    for label, i in [("high_risk", int(np.argmax(risk))), ("low_risk", int(np.argmin(risk)))]:
        explain.save_waterfall(sv[i], base, X_shap.iloc[i], out / f"shap_waterfall_{label}.png")
        results[f"example_{label}"] = {
            "calibrated_pd": float(risk[i]),
            "decision": "REJECT" if risk[i] >= threshold else "APPROVE",
            "reasons": explain.reason_codes(
                sv[i], list(X_shap.columns),
                explain.display_values(list(X_shap.columns), X_te.loc[X_shap.index[i]], X_shap.iloc[i].to_numpy())),
        }

    # 6) Persist everything needed for scoring new applicants
    bundle = {"preprocessor": pre, "model": model, "calibrator": calibrator, "threshold": threshold,
              "model_name": best_name, "background": background, "settings": s}
    joblib.dump(bundle, out / "credit_risk_model.joblib")
    with open(out / "metrics.json", "w") as f:
        json.dump(results, f, indent=2)

    if verbose:
        _print_summary(results)
    return results


def _print_summary(r: dict):
    raw, cal = r["test_uncalibrated"], r["test_calibrated"]
    print("\n=== TEST SET RESULTS ===")
    print(f"ROC-AUC {cal['roc_auc']:.4f} | Gini {cal['gini']:.4f} | KS {cal['ks']:.4f} | PR-AUC {cal['pr_auc']:.4f}")
    print(f"Brier : {raw['brier']:.4f} -> {cal['brier']:.4f} (before -> after calibration)")
    print(f"ECE   : {raw['ece']:.4f} -> {cal['ece']:.4f}")
    print(f"Mean predicted PD {cal['mean_predicted_pd']:.3f} vs observed default rate {cal['observed_default_rate']:.3f}")
    d = r["test_calibrated_at_default_0.5"]
    print(f"Cost/loan @ optimal threshold {cal['threshold']:.2f}: {cal['cost_per_loan']:.4f} "
          f"| @ 0.50: {d['cost_per_loan']:.4f} | best naive policy: {cal['baseline_cost_per_loan']:.4f}")
    print(f"Recall {cal['recall']:.3f} | Precision {cal['precision']:.3f} "
          f"| TP {cal['tp']} FP {cal['fp']} FN {cal['fn']} TN {cal['tn']}")
    print("\nTop SHAP features:")
    for row in r["top_shap_features"][:5]:
        print(f"  {row['feature']:<28s} {row['mean_abs_shap']:.4f}")
