"""Feature preprocessing pipeline."""
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .config import CATEGORICAL_FEATURES, NUMERIC_FEATURES


def build_preprocessor(scale_numeric: bool) -> ColumnTransformer:
    """Median-impute (+ optionally scale) numerics; mode-impute + one-hot categoricals.
    Scaling matters for logistic regression but not for trees."""
    num_steps = [("impute", SimpleImputer(strategy="median"))]
    if scale_numeric:
        num_steps.append(("scale", StandardScaler()))
    cat = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    return ColumnTransformer(
        [("num", Pipeline(num_steps), NUMERIC_FEATURES), ("cat", cat, CATEGORICAL_FEATURES)],
        verbose_feature_names_out=False,
    )
