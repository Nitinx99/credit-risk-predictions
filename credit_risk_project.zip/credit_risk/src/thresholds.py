"""Decision-threshold optimisation (cost-sensitive, plus F1 and Youden's J for reference)."""
import numpy as np
import pandas as pd


def confusion_counts(y, p, threshold):
    """Positive class = default. Predicted default when p >= threshold (loan rejected)."""
    y = np.asarray(y).astype(int)
    pred = np.asarray(p) >= threshold
    tp = int(np.sum(pred & (y == 1)))
    fp = int(np.sum(pred & (y == 0)))
    fn = int(np.sum(~pred & (y == 1)))
    tn = int(np.sum(~pred & (y == 0)))
    return tp, fp, fn, tn


def sweep_thresholds(y, p, cost_fn=5.0, cost_fp=1.0, grid=None) -> pd.DataFrame:
    if grid is None:
        grid = np.round(np.arange(0.01, 1.0, 0.01), 2)
    rows = []
    for t in grid:
        tp, fp, fn, tn = confusion_counts(y, p, t)
        tpr = tp / (tp + fn) if (tp + fn) else 0.0
        fpr = fp / (fp + tn) if (fp + tn) else 0.0
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        f1 = 2 * precision * tpr / (precision + tpr) if (precision + tpr) else 0.0
        rows.append({
            "threshold": float(t), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "recall": tpr, "precision": precision, "f1": f1, "youden_j": tpr - fpr,
            "cost": cost_fn * fn + cost_fp * fp,
            "cost_per_loan": (cost_fn * fn + cost_fp * fp) / len(np.asarray(y)),
        })
    return pd.DataFrame(rows)


def _pick(curve: pd.DataFrame, column: str, minimize: bool):
    best = curve[column].min() if minimize else curve[column].max()
    ties = curve.loc[np.isclose(curve[column], best), "threshold"]
    return float(np.median(ties))  # middle of the plateau is the most stable choice


def optimize_threshold(y, p, cost_fn=5.0, cost_fp=1.0):
    """Return the cost-minimising threshold and reference thresholds."""
    if cost_fn <= 0 or cost_fp <= 0:
        raise ValueError("Costs must be positive")
    curve = sweep_thresholds(y, p, cost_fn, cost_fp)
    return {
        "best_threshold": _pick(curve, "cost", True),
        "f1_threshold": _pick(curve, "f1", False),
        "youden_threshold": _pick(curve, "youden_j", False),
        # With perfectly calibrated probabilities the Bayes-optimal cut is cost_fp / (cost_fp + cost_fn).
        "theoretical_threshold": cost_fp / (cost_fp + cost_fn),
        "curve": curve,
    }
