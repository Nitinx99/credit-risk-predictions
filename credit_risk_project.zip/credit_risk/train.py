"""Run the full pipeline:  python train.py [--csv data.csv] [--samples 20000]"""
import argparse

from src.config import Settings
from src.pipeline import run_pipeline


def main():
    ap = argparse.ArgumentParser(description="Credit risk assessment pipeline")
    ap.add_argument("--csv", default=None, help="Optional CSV with the configured columns (see src/config.py)")
    ap.add_argument("--samples", type=int, default=20000, help="Rows of synthetic data if no CSV is given")
    ap.add_argument("--cost-fn", type=float, default=5.0, help="Cost of approving a loan that defaults")
    ap.add_argument("--cost-fp", type=float, default=1.0, help="Cost of rejecting a good customer")
    ap.add_argument("--calibration", choices=["auto", "isotonic", "sigmoid"], default="auto")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    s = Settings(seed=a.seed, n_samples=a.samples, cost_fn=a.cost_fn, cost_fp=a.cost_fp,
                 calibration_method=a.calibration)
    run_pipeline(s, csv_path=a.csv)


if __name__ == "__main__":
    main()
