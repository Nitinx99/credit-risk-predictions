import numpy as np
import pandas as pd
import pytest
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression

from src import explain
from src.calibration import ProbabilityCalibrator
from src.config import CATEGORICAL_FEATURES, NUMERIC_FEATURES, TARGET, Settings
from src.data import generate_synthetic_data, load_data, validate_dataframe
from src.metrics import evaluate, expected_calibration_error
from src.pipeline import run_pipeline, split_data
from src.predict import SAMPLE_APPLICANT, load_bundle, score_applicants
from src.preprocessing import build_preprocessor
from src.thresholds import confusion_counts, optimize_threshold


# ---------- data ----------
def test_data_shape_and_target():
    df = generate_synthetic_data(2000, seed=1)
    assert len(df) == 2000
    assert set(df[TARGET].unique()) == {0, 1}
    assert 0.03 < df[TARGET].mean() < 0.5
    assert df[NUMERIC_FEATURES].isna().any().any()  # missing values injected on purpose


def test_validation_errors():
    df = generate_synthetic_data(500)
    with pytest.raises(ValueError):
        validate_dataframe(df.drop(columns=["age"]))
    bad = df.copy()
    bad[TARGET] = 2
    with pytest.raises(ValueError):
        validate_dataframe(bad)
    with pytest.raises(FileNotFoundError):
        load_data("does_not_exist.csv")


def test_split_is_disjoint_and_stratified():
    df = generate_synthetic_data(5000)
    parts = split_data(df, Settings())
    idx = [set(X.index) for X, _ in parts]
    assert sum(len(i) for i in idx) == len(df)
    assert len(set.union(*idx)) == len(df)
    rates = [y.mean() for _, y in parts]
    assert max(rates) - min(rates) < 0.02


# ---------- calibration ----------
@pytest.mark.parametrize("method", ["isotonic", "sigmoid"])
def test_calibrator_fixes_miscalibration(method):
    rng = np.random.default_rng(0)
    true_p = rng.uniform(0.01, 0.6, 20000)
    y = (rng.random(20000) < true_p).astype(int)
    overconfident = np.clip(true_p ** 0.5 * 0.9, 0.001, 0.999)   # systematically wrong
    cal = ProbabilityCalibrator(method).fit(overconfident, y)
    out = cal.predict(overconfident)
    assert expected_calibration_error(y, out) < expected_calibration_error(y, overconfident)
    assert out.min() > 0 and out.max() < 1
    order = np.argsort(overconfident)
    assert np.all(np.diff(out[order]) >= -1e-9)  # monotone


def test_calibrator_errors():
    with pytest.raises(ValueError):
        ProbabilityCalibrator("bogus")
    with pytest.raises(RuntimeError):
        ProbabilityCalibrator().predict([0.5])
    with pytest.raises(ValueError):
        ProbabilityCalibrator().fit([0.2, 0.3], [0, 0])


# ---------- thresholds ----------
def test_threshold_matches_bayes_optimum_for_calibrated_probs():
    rng = np.random.default_rng(1)
    p = rng.uniform(0, 1, 200000)
    y = (rng.random(200000) < p).astype(int)   # perfectly calibrated
    res = optimize_threshold(y, p, cost_fn=5, cost_fp=1)
    assert abs(res["best_threshold"] - 1 / 6) < 0.03
    assert res["theoretical_threshold"] == pytest.approx(1 / 6)


def test_threshold_costs_and_counts():
    y = np.array([1, 1, 0, 0, 0])
    p = np.array([0.9, 0.4, 0.3, 0.2, 0.1])
    assert confusion_counts(y, p, 0.35) == (2, 0, 0, 3)
    assert confusion_counts(y, p, 0.5) == (1, 0, 1, 3)
    res = optimize_threshold(y, p, 5, 1)
    assert res["curve"]["cost"].min() == 0
    with pytest.raises(ValueError):
        optimize_threshold(y, p, 0, 1)


# ---------- metrics ----------
def test_metrics_keys_and_ranges():
    rng = np.random.default_rng(2)
    p = rng.uniform(0, 1, 5000)
    y = (rng.random(5000) < p).astype(int)
    m = evaluate(y, p, 0.2)
    assert 0.78 < m["roc_auc"] < 0.88
    assert m["tp"] + m["fp"] + m["fn"] + m["tn"] == 5000
    assert m["ece"] < 0.05


# ---------- SHAP ----------
def _small_matrices():
    df = generate_synthetic_data(3000, seed=3)
    X, y = df.drop(columns=[TARGET]), df[TARGET]
    return X, y


@pytest.mark.parametrize("kind", ["tree", "linear"])
def test_shap_additivity(kind):
    X, y = _small_matrices()
    pre = build_preprocessor(scale_numeric=(kind == "linear")).fit(X)
    Xt = pd.DataFrame(pre.transform(X), columns=pre.get_feature_names_out())
    model = (GradientBoostingClassifier(n_estimators=50, random_state=0) if kind == "tree"
             else LogisticRegression(max_iter=2000)).fit(Xt, y)
    ex = explain.build_explainer(model, Xt.sample(100, random_state=0))
    sv, base = explain.shap_values(ex, Xt.iloc[:100])
    margin = model.decision_function(Xt.iloc[:100])
    assert sv.shape == (100, Xt.shape[1])
    np.testing.assert_allclose(sv.sum(axis=1) + base, margin, atol=1e-3)


def test_reason_codes_only_positive():
    vals = np.array([0.5, -0.2, 0.1, 0.0])
    rc = explain.reason_codes(vals, ["a", "b", "c", "d"], np.array([1.0, 2.0, 3.0, 4.0]), top_k=3)
    assert len(rc) == 2 and rc[0].startswith("a")


# ---------- end to end ----------
def test_pipeline_end_to_end(tmp_path):
    s = Settings(n_samples=4000, shap_sample_size=60)
    res = run_pipeline(s, output_dir=tmp_path, verbose=False)
    for f in ["metrics.json", "credit_risk_model.joblib", "calibration_curve.png", "threshold_curve.png",
              "roc_curve.png", "shap_summary.png", "shap_importance_bar.png",
              "shap_waterfall_high_risk.png", "shap_waterfall_low_risk.png", "threshold_sweep.csv"]:
        assert (tmp_path / f).exists(), f
    cal = res["test_calibrated"]
    assert cal["roc_auc"] > 0.6
    assert abs(cal["mean_predicted_pd"] - cal["observed_default_rate"]) < 0.03
    assert cal["cost_per_loan"] <= res["test_calibrated_at_default_0.5"]["cost_per_loan"] * 1.05

    bundle = load_bundle(tmp_path / "credit_risk_model.joblib")
    out = score_applicants(bundle, pd.DataFrame([SAMPLE_APPLICANT]))
    assert 0 < out["probability_of_default"].iloc[0] < 1
    assert out["decision"].iloc[0] in {"APPROVE", "REJECT"}


def test_scoring_handles_missing_and_unseen_values(tmp_path):
    run_pipeline(Settings(n_samples=3000, shap_sample_size=30), output_dir=tmp_path, verbose=False)
    bundle = load_bundle(tmp_path / "credit_risk_model.joblib")
    a = dict(SAMPLE_APPLICANT, employment_years=np.nan, loan_purpose="wedding")  # NaN + unseen category
    out = score_applicants(bundle, pd.DataFrame([a]))
    assert np.isfinite(out["probability_of_default"].iloc[0])
    with pytest.raises(ValueError):
        score_applicants(bundle, pd.DataFrame([{"age": 30}]))
